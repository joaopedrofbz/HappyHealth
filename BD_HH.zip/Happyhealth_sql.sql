/************************************************************
    Grupo: Happy Health    |  Curso: L-IG
*  	UC: Bases de Dados
*
*	Pojeto: Happy Health   
*
*  	Nome: João Ramos(20200255)
*  	Nome: Tomás Gomes (20201004)
    Nome: Éder Weide (20200295)
*
************************************************************/
DROP DATABASE IF EXISTS happyhealth;
create database HappyHealth;
use HappyHealth;

/************************************************************
*  Lista de Entidades Informaconais Primárias
************************************************************/
CREATE TABLE CodPostal
(
  CP_id INT AUTO_INCREMENT,
  CP_4d INT NOT NULL, -- valida a regra de negocio nº8 é obrigatório ter um codigo postal
  CP_3d INT NOT NULL,
  CP_concelho VARCHAR(35),
  CP_freguesia VARCHAR(35),
  PRIMARY KEY (CP_id)
);



create table exercicio(
	Exer_id int not null auto_increment,
    Exer_Tipo VarChar(40),
	Exer_Ritmo int not null,
	Exer_Inicio VARCHAR(150) ,
    Exer_Final VARCHAR(150),
	Exer_Kilometro int,
	primary key (Exer_id)
);

CREATE TABLE Aulas
(
    Au_id Int auto_increment,
    Au_Nome varchar(150),
    Au_Tempo int not null,
    Au_Local varchar(60) not null,
    Au_Tipo varchar(40) not null,
    Au_Data varchar(30) not null,
    check(Au_Tempo<=45), -- Regra de negocio nº3 aula nao pode utltrapassar os 45mins
    primary key (Au_id)
);

CREATE TABLE Forum
(
    For_id Int auto_increment,
    For_Mensagem char,
    For_Post char not null,
    UT_id int NOT NULL,
    Prof_id int NOT NULL,
    primary key (For_id)
);

create table Notificacao (
	Not_id int auto_increment,
	Not_Tipo VARCHAR(30),
	Not_Descricao VARCHAR(200),
    UT_not_id int ,
	primary key (Not_id)
);  
create table Utilizadores (
	UT_id int not null auto_increment,
	UT_NProprio varchar(40) not null , -- valida a regra de negocio Nº11
	UT_Apelido varchar(40) not null, -- valida a regra de negocio Nº13
	UT_DataNasc datetime not null, 
	UT_Genero char(1) not null, 
    UT_nif varchar(9),
    Ut_TotalPontos int not null default 0,  -- valida a regra de negocio nº7 - todos os utilizadores tem como default 0 pontos 
    unique (ut_nif), -- valida a regra de negocio nº6 o nif é unico para utlizador
    CHECK (65 >=2021 - year(ut_dataNasc)<= 130), -- valida a regra de negocio nº2 o utilizador nao pode ter menos de 65 anos
    primary key (UT_id)
);  

CREATE TABLE Professor
(
    prof_id Int auto_increment,
    prof_genero char(1) ,
    prof_datanasc date not null,
    prof_NomeProp varchar(40) not null, -- valida a regra de negocio Nº12
    prof_Apelido varchar(40) not null, -- valida a regra de negocio Nº14
    prof_nif char(9) not null, -- valida a regra de negócio nº9 o professor é obrgiado a ter nif inserido
	unique (prof_nif), -- valida a regra de negocio nº6 o nif é unico para professor
    CHECK (18 >=2021 - year(prof_dataNasc)<= 130), -- valida a regra de negocio nº1 o professor nao pode ter menos de 18 anos
    primary key (prof_id)
);
/************************************************************
*  Lista de Entidades Informaconais com FK
************************************************************/

 CREATE TABLE Pontuacao
(
    Pon_id Int auto_increment,
	ut_id int not null,
    primary key (Pon_id),
    foreign key(ut_id) references utilizadores(ut_id)
);
                     
CREATE TABLE Utilizador_UT_contactos
(
  UT_contactos VARCHAR(60) NOT NULL, -- validade regra de negocio nº10 É obrigatorio haver um contacto
  UT_Contactos_id INT NOT NULL,
  unique (ut_contactos), -- validade regra de negocio nº4 nao pode haver mais de um registro com o mesmo contacto
  PRIMARY KEY (UT_contactos,UT_Contactos_id),
  FOREIGN KEY (UT_Contactos_id) REFERENCES Utilizadores(UT_id)
  );
  
CREATE TABLE Professor_prof_contactos
(
  prof_contactos VARCHAR(60) NOT NULL, -- validade regra de negocio nº10 É obrigatorio haver um contacto
  prof_id INT NOT NULL,
  UNIQUE (prof_Contactos), -- validade regra de negocio nº4 nao pode haver mais de um registro com o mesmo contacto
  PRIMARY KEY (prof_contactos, prof_id),
  FOREIGN KEY (prof_ID) REFERENCES Professor(prof_id)
  );
/************************************************************
*  Lista de Entidades Fracas
************************************************************/	

CREATE TABLE Recompensas
(
    Rec_id Int auto_increment,
    Rec_Nome varchar(200),
    Rec_PontosNecessarios int not null,
    rec_pon_id int,
    primary key (Rec_id),
	FOREIGN KEY(rec_Pon_id) REFERENCES pontuacao(pon_id)
);
/************************************************************
*  Lista de Entidades de Associação
************************************************************/	

CREATE TABLE Fazer
(
  UT_id INT NOT NULL,
  Exer_id INT NOT NULL,
  PRIMARY KEY (UT_id,Exer_id),
  FOREIGN KEY (UT_id) REFERENCES Utilizadores(UT_id),
  FOREIGN KEY (Exer_id) REFERENCES exercicio(Exer_id)
);

CREATE TABLE Receber
(
  Exer_id INT NOT NULL,
  Au_ID INT NOT NULL,
  Pon_ID INT NOT NULL,
  PRIMARY KEY (Au_ID,Exer_id),
  FOREIGN KEY (Au_ID) REFERENCES Aulas(Au_ID),
  FOREIGN KEY (Exer_id) REFERENCES Exercicio(Exer_id),
  FOREIGN KEY (Pon_ID) REFERENCES Pontuacao(Pon_ID)
  
);

CREATE TABLE Aceder
(
  Ac_data TIMESTAMP not null,
  UT_id INT,
  For_ID int not null,
  prof_id int,
  PRIMARY KEY (UT_id, For_ID, prof_id),
  FOREIGN KEY (UT_id) REFERENCES Utilizadores(UT_id),
  FOREIGN KEY (For_ID) REFERENCES Forum(For_ID),
  FOREIGN KEY (prof_id) REFERENCES Professor(prof_id)
);

CREATE TABLE Enviar
(
  UT_id INT NOT NULL,
  prof_id int not null,
  Not_id int not null,
  PRIMARY KEY (UT_id, Not_id, prof_id),
  FOREIGN KEY (UT_id) REFERENCES Utilizadores(UT_id),
  FOREIGN KEY (prof_id) REFERENCES Professor(prof_id),
  FOREIGN KEY (Not_id) REFERENCES Notificacao(Not_id)
);
CREATE TABLE Inscrever
(
  insc_id int not null auto_increment,	
  UT_id INT NOT NULL,
  Au_ID INT NOT NULL,
  Insc_Data TIMESTAMP NOT NULL,
  primary key(insc_id),
  FOREIGN KEY (UT_id) REFERENCES Utilizadores(UT_id),
  FOREIGN KEY (Au_ID) REFERENCES Aulas(Au_ID)
);

CREATE TABLE Lecionar
(
prof_id int not null,
Au_ID INT NOT NULL,
primary key(prof_id, Au_ID),
FOREIGN KEY (prof_id) REFERENCES Professor(prof_id),
FOREIGN KEY (Au_ID) REFERENCES Aulas(Au_ID)
);

CREATE TABLE Residir
(
 UT_id INT NOT NULL,
 cp_id int not null,
 Res_data TIMESTAMP NOT NULL,
 FOREIGN KEY (cp_id) REFERENCES CodPostal(cp_id),
 FOREIGN KEY (UT_id) REFERENCES Utilizadores(UT_id)
);
CREATE TABLE Morar
(
 prof_id INT NOT NULL,
 cp_id int not null,
 Mor_data TIMESTAMP NOT NULL,
 FOREIGN KEY (cp_id) REFERENCES CodPostal(cp_id),
 FOREIGN KEY (prof_id) REFERENCES professor(prof_id)
);

