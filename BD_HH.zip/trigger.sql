 DELIMITER //

CREATE TRIGGER trg_Utilizador BEFORE INSERT ON utilizadores
FOR EACH ROW
BEGIN
	-- variable declarations
    DECLARE varIdade int DEFAULT 0;
	    
    -- intersecta a insercao de um novo registo na tabele para determinar o valor da idade
    SET varIdade = TIMESTAMPDIFF(YEAR, NEW.ut_datanasc, CURDATE());
	
    -- verifica se a idade do cliente > 18 anos
    IF varIdade <= 65 THEN
		SIGNAL SQLSTATE '50001' SET MESSAGE_TEXT = 'o utilizador tem de ter mais de 65 anos';
		-- Obs.: MySQL não permite que seja utilizada outra instrução de gravação, na mesma tebela, dentro de um trigger
    END IF;
	
END// -- Trigger
DELIMITER //
DELIMITER //
CREATE TRIGGER trg_prof BEFORE INSERT ON professor
FOR EACH ROW
BEGIN
	-- variable declarations
    DECLARE varIdade int DEFAULT 0;
	    
    -- intersecta a insercao de um novo registo na tabele para determinar o valor da idade
    SET varIdade = TIMESTAMPDIFF(YEAR, NEW.prof_datanasc, CURDATE());
	
    -- verifica se a idade do cliente > 18 anos
    IF varIdade < 18 THEN
		SIGNAL SQLSTATE '50001' SET MESSAGE_TEXT = 'o professor tem de ter mais de 18 anos';
		-- Obs.: MySQL não permite que seja utilizada outra instrução de gravação, na mesma tebela, dentro de um trigger
    END IF;
	
END// -- Trigger
 DELIMITER //
  DELIMITER //
CREATE TRIGGER ut_AntesDelete BEFORE DELETE ON utilizadores FOR EACH ROW
BEGIN
signal sqlstate '45000' set message_text= ' Não é permitido concluir esta operação';
END// -- nao permite apagar o registo de qualquer utilizador
DELIMITER //
DELIMITER //
CREATE TRIGGER prof_AntesDelete BEFORE DELETE ON professor FOR EACH ROW
BEGIN
signal sqlstate '45000' set message_text= ' Não é permitido concluir esta operação';
END// -- nao permite apagar o registo de qualquer professor
DELIMITER //
DELIMITER //
Create trigger trg_enviarpontos after insert on inscrever for each row
begin

	update utilizadores 
    set ut_TotalPontos = ut_TotalPontos+20
	where ut_id=new.ut_id;
	

end// -- adiciona 20 pontos quando se inscreve em uma aula 
DELIMITER //
-- insert into inscrever (UT_id, Au_ID, Insc_Data) values (1,1,'2002.06.01'); -

 -- select * from utilizadores-- wawd
DELIMITER //
Create trigger trg_enviapontosexer after insert on fazer for each row
begin

	update utilizadores 
    set ut_TotalPontos = ut_TotalPontos+5 
	where ut_id=new.ut_id;
	

end// -- adiciona 5 pontos quando inicia exercicio fisico 
DELIMITER //
DELIMITER //
Create trigger trg_enviapontosforum after insert on aceder for each row
begin

	update utilizadores
    set ut_TotalPontos = ut_TotalPontos+2
	where ut_id=new.ut_id;
	

end//  -- adiciona 2 pontos quando o utilizador cria um novo post
DELIMITER //



create trigger tr_insutilizador before insert on utilizadores for each row 
set new.UT_NProprio = uppper(NEW.UT_NProprio);

drop trigger  tr_insutilizador;

create trigguer tr_up_utilizador
before insert on utilizadores
for each row
Set new.UT_NProprio = lower(New.UT_NProprio);


-- 1 triguer com 2 tabelas
-- comentar esta merda toda

